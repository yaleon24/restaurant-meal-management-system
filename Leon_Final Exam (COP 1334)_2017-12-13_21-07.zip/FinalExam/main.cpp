#include <iostream>
#include <vector>
using namespace std;

struct Meal
{
    string fside,sside, maincourse;
    int mcal,fcal,scal;
};

int main()
{
    char choice;
    int total=0,sides=0;
    bool tocontinue=true;
    vector<Meal>v;
    Meal b;
    do
    {
        cout << "Enter 1 to add a new meal." << endl;
        cout << "Enter 2 to show the total calories for all the meals." << endl;
        cout << "Enter 3 to show all the main courses entered." << endl;
        cout << "Enter 4 to quit the program." << endl;
        cin>> choice;
        switch(choice)
        {
        case '1':
            cin.ignore();
            cout << "Enter the main course." << endl;
            getline(cin,b.maincourse);

            cout << "Enter the calories for the main course." << endl;
            cin>>b.mcal;
            cin.ignore();
            cout << "Enter the first side." << endl;
            getline(cin,b.fside);
            cout << "Enter the calories for the first side." << endl;
            cin>>b.fcal;
            cin.ignore();
            cout << "Enter the second side." << endl;
            getline(cin,b.sside);
            cout << "Enter the calories for the second side." << endl;
            cin>>b.scal;
            v.push_back(b);
        break;
        case '2':
            cout << "Total calories for all meals " << endl;
             for(int i=0; i<v.size(); i++)
            {

            total+=v[i].mcal+v[i].fcal+v[i].scal;
            }
             cout<<total<<endl;
         break;
        case '3':
            for(int i=0;i<v.size();i++){


            cout<<v[i].maincourse<<endl;
            }
        break;
        case '4':
            tocontinue=false;

       break;
        }
 }while(tocontinue);
///////////////////////////////



    return 0;
}
